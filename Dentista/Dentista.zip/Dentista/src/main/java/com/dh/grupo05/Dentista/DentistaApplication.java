package com.dh.grupo05.Dentista;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DentistaApplication {

	public static void main(String[] args) {
		SpringApplication.run(DentistaApplication.class, args);
	}

}
