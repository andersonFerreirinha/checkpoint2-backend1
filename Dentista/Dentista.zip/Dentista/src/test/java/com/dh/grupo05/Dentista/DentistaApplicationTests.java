package com.dh.grupo05.Dentista;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DentistaApplicationTests {

	@Test
	void contextLoads() {
	}

}
